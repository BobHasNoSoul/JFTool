#!/bin/bash
sudo cp ./animation/stylefix.css /usr/lib/jellyfin/bin/jellyfin-web/components/htmlvideoplayer/style.css
sudo cp ./animation/pattysday.html /usr/lib/jellyfin/bin/jellyfin-web/index.html
sudo cp ./animation/lep_30x30.png /usr/lib/jellyfin/bin/jellyfin-web/
sudo cp ./animation/clover_20x20.png /usr/lib/jellyfin/bin/jellyfin-web
