#!/bin/bash
sudo cp ./animation/stylefix.css /usr/lib/jellyfin/bin/jellyfin-web/components/htmlvideoplayer/style.css
sudo cp ./animation/fireworks.html /usr/lib/jellyfin/bin/jellyfin-web/index.html
sudo cp ./animation/fireworks.css /usr/lib/jellyfin/bin/jellyfin-web/fireworks.css
