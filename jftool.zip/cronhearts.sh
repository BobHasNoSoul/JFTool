#!/bin/bash
sudo cp ./animation/stylefix.css /usr/lib/jellyfin/bin/jellyfin-web/components/htmlvideoplayer/style.css
sudo cp ./animation/valentines.html /usr/lib/jellyfin/bin/jellyfin-web/index.htm
