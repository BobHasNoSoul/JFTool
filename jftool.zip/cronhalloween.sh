#!/bin/bash
sudo cp ./animation/stylefix.css /usr/lib/jellyfin/bin/jellyfin-web/components/htmlvideoplayer/style.css
sudo cp ./animation/halloween.html /usr/lib/jellyfin/bin/jellyfin-web/index.html
sudo cp ./animation/ghost_20x20.png /usr/lib/jellyfin/bin/jellyfin-web/
sudo cp ./animation/bat_20x20.png /usr/lib/jellyfin/bin/jellyfin-web/
sudo cp ./animation/pumpkin_20x20.png /usr/lib/jellyfin/bin/jellyfin-web/
